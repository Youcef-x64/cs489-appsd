package lab1a;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ProductMgmtApp {
    public static void main(String[] args) {
        List<Product> products = new ArrayList<>();

        products.add(new Product(3128874119L, "Banana", LocalDate.of(2023, 1, 24), 124, 0.55F));
        products.add(new Product(2927458265L, "Apple", LocalDate.of(2022, 12, 9), 18, 1.09F));
        products.add(new Product(9189927462L, "Carrot", LocalDate.of(2023, 3, 31), 89, 2.99F));

        System.out.println("Printed in JSON Format");
        System.out.println(convertProductListToJson(products));

        System.out.println("---------------------------------");
        System.out.println("Printed in XML Format");
        System.out.println(convertProductListToXml(products));

        System.out.println("---------------------------------");
        System.out.println("Printed in CSV Format");
        System.out.println(convertProductListToCsv(products));
    }

    private static String convertProductListToJson(List<Product> productList) {
        StringBuilder jsonBuilder = new StringBuilder();
        jsonBuilder.append("[\n");

        for (int i = 0; i < productList.size(); i++) {
            Product product = productList.get(i);
            jsonBuilder.append("{");

            // Add product attributes to JSON object
            jsonBuilder.append("\"productId\": ").append(product.getProductId()).append(", ");
            jsonBuilder.append("\"name\": \"").append(product.getName()).append("\", ");
            jsonBuilder.append("\"dateSupplied\": \"").append(product.getDateSupplied()).append("\", ");
            jsonBuilder.append("\"quantityInStock\": ").append(product.getQuantityInStock()).append(", ");
            jsonBuilder.append("\"unitPrice\": ").append(product.getUnitPrice());

            jsonBuilder.append("}"); // End of JSON object

            // Add comma if not the last element
            if (i < productList.size() - 1) {
                jsonBuilder.append(", \n");
            }
        }

        jsonBuilder.append("\n]"); // End of JSON array
        return jsonBuilder.toString();
    }

    private static String convertProductListToXml(List<Product> productList) {
        StringBuilder xmlBuilder = new StringBuilder();
        xmlBuilder.append("<products>\n");

        for (Product product : productList) {
            xmlBuilder.append("<product ");
            xmlBuilder.append("productId=\"").append(product.getProductId()).append("\" ");
            xmlBuilder.append("name=\"").append(product.getName()).append("\" ");
            xmlBuilder.append("dateSupplied=\"").append(product.getDateSupplied()).append("\" ");
            xmlBuilder.append("quantityInStock=\"").append(product.getQuantityInStock()).append("\" ");
            xmlBuilder.append("unitPrice=\"").append(product.getUnitPrice()).append("\" ");
            xmlBuilder.append("/>\n");
        }

        xmlBuilder.append("</products>");
        return xmlBuilder.toString();
    }

    private static String convertProductListToCsv(List<Product> productList) {
        StringBuilder csvBuilder = new StringBuilder();

        // Append CSV header
        csvBuilder.append("productId,name,dateSupplied,quantityInStock,unitPrice\n");

        // Append data for each product
        for (Product product : productList) {
            csvBuilder.append(product.getProductId()).append(",");
            csvBuilder.append("\"").append(product.getName()).append("\",");
            csvBuilder.append(product.getDateSupplied()).append(",");
            csvBuilder.append(product.getQuantityInStock()).append(",");
            csvBuilder.append(product.getUnitPrice()).append("\n");
        }

        return csvBuilder.toString();
    }
}